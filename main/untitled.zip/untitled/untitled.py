from flask import Flask,render_template,request,session,jsonify

from flask_mail import Mail, Message
import time
import datetime
from DBConnection import Db
app = Flask(__name__)
app.secret_key="fff333"
mail= Mail(app)

app.config['MAIL_SERVER']='smtp.gmail.com'
app.config['MAIL_PORT'] = 465
app.config['MAIL_USERNAME'] = 'devagiricollege.leavemanagement@gmail.com'
app.config['MAIL_PASSWORD'] = 'devagirileavemanagement'
app.config['MAIL_USE_TLS'] = False
app.config['MAIL_USE_SSL'] = True
mail = Mail(app)




staticpath="C:\\Users\\Dell\\Desktop\\DVG\\project\\main\\untitled\\static\\"


@app.route('/')
def adminhome():
    return render_template('LOGIN PAGE.html')

@app.route('/login_post', methods=['post'])
def login_post():
    username=request.form['textfield']
    password=request.form['textfield2']
    db=Db()
    import datetime
    dd=str(datetime.datetime.today().now())
    ss=dd.split(" ")
    dd=ss[0]
    qry="select * from login where username='"+username+"' and password='"+password+"'"
    res=db.selectOne(qry)
    session['l_id']=res['login_ID']
    session["dd"]=str(dd)
    if res is not None:
        type=res['type']
        if type=="admin":

            return render_template('admin/home.html')
        elif type=="teacher":
            return render_template('teacher/home.html')
        else:
            return 'invalid username or password'
    else:
        return 'invalid username or password'




@app.route('/adm_home')
def adm_home():
    return render_template('admin/home.html')

@app.route('/adm_add_course')
def adm_add_course():
    return render_template('admin/ADD COURSE.html')


@app.route('/adm_add_course_post',methods=['post'])
def adm_add_course_post():
    coursename=request.form['textfield']
    noofsem=request.form['textfield2']
    db=Db()
    qry="insert into course(coursename,duration)values('"+coursename+"','"+noofsem+"')"
    print(qry)
    res=db.insert(qry)
    print(res)
    return render_template('admin/ADD COURSE.html')







@app.route('/admin_addsub')
def admin_addsub():
    c = Db()
    qry = "select * from course"
    res = c.select(qry)
    return render_template('admin/ADD SUB.html',data=res)

@app.route('/admin_addsub_post',methods=['post'])
def admin_addsub_post():
    coursename= request.form['select']
    subname=request.form['textfield2']
    subcode=request.form['textfield3']
    semester=request.form['select2']

    db = Db()
    qry = "insert into subject(course_name,subject_name,subcode,semester)values('" + coursename+ "','"+subname+"','" + subcode + "','"+semester+"')"
    res = db.insert(qry)

    return admin_addsub()







@app.route('/teacherhome')
def teacherhome():
    return render_template('admin/teacher_profile.html')


@app.route('/admin_add_staff')
def admin_addstaff():
    return render_template('admin/add.staff.html')

@app.route('/admin_add_staff_post',methods=['post'])
def admin_addstaff_post():
    name=request.form['textfield']
    photo=request.files['fileField']
    age=request.form['textfield2']
    gender=request.form['RadioGroup1']
    Experience=request.form['textfield3']
    email=request.form['textfield4']
    phone=request.form['textfield5']
    house_name=request.form['textfield7']
    house_number=request.form['textfield7']
    city=request.form['textfield77']
    district=request.form['select']
    state=request.form['textfield10']
    pincode=request.form['textfield9']


    dt = time.strftime("%Y%m%d-%H%M%S")
    photo.save(staticpath+"staff_image\\"+dt+".jpg")
    path = "/static/staff_image/"+dt+".jpg"

    db = Db()
    qry2="insert into login(username,password,type)values('"+email+"','"+phone+"','teacher')"
    res2=db.insert(qry2)

    qry = "insert into staff(staff_name,experience,staff_photo,mail_id,phone_number,house_name,house_number,city,district,pincode,state,login_ID,age,gender) values('"+name+"','"+Experience+"','"+path+"','"+email+"','"+phone+"','"+house_name+"','"+house_number+"','"+city+"','"+district+"','"+pincode+"','"+state+"','"+str(res2)+"','"+age+"','"+gender+"')"
    res = db.insert(qry)
    print(res)

    return render_template('admin/add.staff.html')


@app.route('/admin_ADMIN_EDIT_COURSES/<id>')
def admin_admin_edit_courses(id):
    db=Db()
    qry="select * from course WHERE course_id = '"+str(id)+"'"
    res=db.selectOne(qry)
    print(res)
    return render_template('admin/ADMIN EDIT COURSE.html',data=res)

@app.route('/admin_ADMIN_DELETE_COURSES/<id>')
def admin_admin_delete_courses(id):
    db=Db()
    qry="delete from course WHERE course_id = '"+str(id)+"'"
    res=db.delete(qry)

    return "<script>alert('Deleted Successfully ');window.location='/admin_ADMIN_VIEW_COURSES'</script>"






@app.route('/admin_ADMIN_EDIT_COURSES_post',methods=['post'])
def admin_admin_edit_courses_post():
    id=request.form['iid']
    coursename=request.form['textfield']
    totsem=request.form['textfield2']
    db=Db()
    qry= "update course set coursename= '"+coursename+"',duration='"+totsem+"' WHERE  course_id ='"+id+"' "
    res=db.update(qry)
    return "<script>alert('Successfully updated');window.location='/admin_ADMIN_VIEW_COURSES'</script>"

@app.route('/admin_edit_timetable/<id>')
def admin_admin_edit_time_table(id):
    c = Db()
    qry = "select * from course"
    res = c.select(qry)
    qry2 = "select * from subject"
    res2 = c.select(qry2)
    print(res2)
    qry5 = "select * from subject inner join time_table on time_table.subject=subject.subject_id where tid='"+id+"'"
    d5 = c.selectOne(qry5)
    print(d5)
    return render_template('admin/Admin Edit Time table.html',data=res,data2=res2,d=d5)

@app.route('/admin_admin_edit_time_table_post',methods=['post'])
def admin_admin_edit_time_table_post():
    course = request.form['select']
    semester = request.form['select2']
    subject = request.form['select3']
    day = request.form['select4']
    hour = request.form['select5']
    tid=request.form["tid"]

    db = Db()
    qry = "UPDATE `time_table` SET `day`='"+day+"',`hour`='"+hour+"',`course`='"+course+"',`semester`='"+semester+"',`subject`='"+subject+"' WHERE `tid`='"+tid+"'"
    print(qry)
    res = db.insert(qry)
    return admin_timetable()

    return "<script>alert('Successfully updated');window.location='/admin_admin_view_time_table'</script>"



@app.route('/admin_ADMIN_VIEW_COURSES')
def admin_admin_view_courses():
    c=Db()
    qry="select * from course"
    res=c.select(qry)
    return render_template('admin/ADMIN VEIW COURSE.html',data=res)


@app.route('/admin_Admin_view_staff.html')
def admin_admin_view_staff():
    c = Db()
    qry = "select * from staff"
    res = c.select(qry)
    return render_template('admin/Admin view staff.html',data=res)


@app.route('/searchstaff',methods=['post'])
def searchstaff():
    search = request.form['select']
    c=Db()
    qry="select * from staff where staff_name like '%"+search+"%'"
    res = c.select(qry)
    return render_template('admin/Admin view staff.html', data=res)


@app.route('/admin_ADMIN_VIEW_COURSES_post',methods=['post'])
def admin_admin_view_courses_post():
    course=request.form['select']

    return render_template('admin/ADMIN VEIW COURSE.html')



@app.route('/admin_Admin_view_staff_post.html',methods=['post'])
def admin_admin_view_staff_post():
    name=request.form['select']
    return render_template('admin/Admin view staff.html')


@app.route('/admin_ADMIN_VIEW_STAFF2/<sid>')
def admin_admin_view_STAFF2(sid):
    qry="select *from staff where staff_id='"+sid+"'"
    c=Db()
    res=c.selectOne(qry)

    return render_template('admin/ADMIN VIEW STAFF2.html',res=res)

@app.route('/admin_ADMIN_EDIT_STAFF2/<sid>')
def admin_admin_edit_STAFF2(sid):
    qry="select *from staff where staff_id='"+sid+"'"
    c=Db()
    res=c.selectOne(qry)
    session["sid"]=sid
    return render_template('admin/admin_edit_staff.html',res=res)

@app.route('/admin_ADMIN_DELETE_STAFF2/<sid>')
def admin_admin_delete_staff2(sid):
    db=Db()
    qry="delete from staff WHERE staff_id = '"+str(sid)+"'"
    res=db.delete(qry)

    return "<script>alert('Deleted Successfully ');window.location='/admin_Admin_view_staff.html'</script>"

@app.route('/admin_ADMIN_EDIT_STAFF2_post',methods=['post'])
def admin_admin_edit_staff2_post():
    name = request.form['textfield']
    id=str(session["sid"])
    age = request.form['textfield2']
    gender = request.form['RadioGroup1']
    Experience = request.form['textfield3']
    email = request.form['textfield4']
    phone = request.form['textfield5']
    house_name = request.form['textfield7']
    house_number = request.form['textfield7']

    # -------------------
    city = request.form['textfield8']
    district = request.form['select']
    state = request.form['textfield10']
    pincode = request.form['textfield9']
    db=Db()

    if 'fileField' in request.files:
        photo = request.files['fileField']
        if photo.filename !="":
            photo.save("C:\\Users\\Pranoy\\PycharmProjects\\untitled\\static\\staff_image\\"+photo.filename)
            path="/static/staff_image/"+photo.filename
            qry="update staff set staff_name='"+name+"',experience='"+Experience+"',staff_photo='"+path+"',age='"+age+"',gender='"+gender+"',mail_id='"+email+"',phone_number='"+phone+"',house_name='"+house_name+"',house_number='"+house_number+"',city='"+city+"',district='"+district+"',pincode='"+pincode+"',state='"+state+"' where staff_id='"+id+"'"
        else:
            qry = "update staff set staff_name='" + name + "',experience='" + Experience + "',age='" + age + "',gender='" + gender + "',mail_id='" + email + "',phone_number='" + phone + "',house_name='" + house_name + "',house_number='" + house_number + "',city='" + city + "',district='" + district + "',pincode='" + pincode + "',state='" + state + "' where staff_id='" + id + "'"

    else:
        qry = "update staff set staff_name='" + name + "',experience='" + Experience + "',age='" + age + "',gender='" + gender + "',mail_id='" + email + "',phone_number='" + phone + "',house_name='" + house_name + "',house_number='" + house_number + "',city='" + city + "',district='" + district + "',pincode='" + pincode + "',state='" + state + "' where staff_id='" + id + "'"

    res=db.update(qry)
    return "<script>alert('Successfully updated');window.location='/admin_Admin_view_staff.html'</script>"

@app.route("/get_subject_according_crs_and_sem")
def changev():
    d=Db()
    id=request.args.get('cid')
    sem = request.args.get('sem')
    query12 = "select * from subject where course_name='"+id+"' and semester='"+sem+"'"
    print(query12)
    res=d.select(query12)
    print(res)
    return jsonify(res)
@app.route('/admin_admin_view_time_table')
def admin_admin_view_time_table():
    c = Db()
    qry = "select * from course"
    res = c.select(qry)


    return render_template('admin/Admin view Time table.html', data=res,status="null")

@app.route('/admin_admin_view_time_table_post',methods=['post'])
def admin_admin_view_time_table_post():
    coursename=request.form['select']
    semester=request.form['select2']
    c = Db()
    qry = "select * from course"
    res = c.select(qry)
    qry1="select subject.subject_id,subject.subject_name,time_table.tid from subject inner join time_table on time_table.subject=subject.subject_id where day='monday' and time_table.course='"+coursename+"' and time_table.semester='"+semester+"'"
    d1=c.select(qry1)
    qry2 = "select subject.subject_id,subject.subject_name,time_table.tid from subject inner join time_table on time_table.subject=subject.subject_id where day='tuesday' and time_table.course='" + coursename + "' and time_table.semester='" + semester + "'"
    d2 = c.select(qry2)
    qry3 = "select subject.subject_id,subject.subject_name,time_table.tid from subject inner join time_table on time_table.subject=subject.subject_id where day='wednesday' and time_table.course='" + coursename + "' and time_table.semester='" + semester + "'"
    d3 = c.select(qry3)
    print(d3)
    qry4 = "select subject.subject_id,subject.subject_name,time_table.tid from subject inner join time_table on time_table.subject=subject.subject_id where day='thursday' and time_table.course='" + coursename + "' and time_table.semester='" + semester + "'"
    d4 = c.select(qry4)
    qry5 = "select subject.subject_id,subject.subject_name,time_table.tid from subject inner join time_table on time_table.subject=subject.subject_id where day='friday' and time_table.course='" + coursename + "' and time_table.semester='" + semester + "'"
    d5 = c.select(qry5)
    return render_template('admin/Admin view Time table.html',data=res,d1=d1,d2=d2,d3=d3,d4=d4,d5=d5,status="full")




@app.route('/admin_admin_edit_staff')
def admin_admin_edit_staff():
    return render_template('admin/admin_edit_staff.html')

@app.route('/admin_admin_edit_staff_post',methods=['post'])
def admin_admin_edit_staff_post():
    name = request.form['textfield']
    photo = request.files['fileField']
    age = request.form['textfield2']
    gender = request.form['RadioGroup1']
    Experience = request.form['textfield3']
    email = request.form['textfield4']
    phone = request.form['textfield5']
    house_name=request.form['textfield12']
    house_number = request.form['textfield7']
    city = request.form['textfield8']
    district = request.form['select']
    state = request.form['textfield10']
    pincode = request.form['textfield9']

    db = Db()
    qry = "insert into staff(staff_name,experience,photo,age,gender,mail_id,phone_number,house_name,house_number,city,district,state,pincode)values('" + name + "','" +Experience+ "','" +photo+"','" + age + "','" + gender + "','"+email+"','"+phone+"','"+house_name+"','"+house_number+"','"+city+"','"+district+"','"+state+"','"+pincode+"')"
    res = db.insert(qry)
    return render_template('admin/admin_edit_staff.html')

@app.route('/admin_admin_edit_sub')
def admin_admin_edit_sub():
    return render_template('admin/admin_edit_sub.html')

@app.route('/admin_admin_edit_sub_post',methods=['post'])
def admin_admin_edit_sub_post():
    course=request.form['select']
    semester=request.form['select2']
    subcode=request.form['textfield']
    subname=request.form['textfield2']
    return render_template('admin/admin_edit_sub.html')


@app.route('/admin_admin_requests')
def admin_admin_admin_requests():
    c=Db()
    qry="select staff.*,leave_req.* from leave_req,staff where leave_req.staff_id=staff.staff_id"
    res=c.select(qry)
    q="select * from staff"
    resa= c.select(qry)
    return render_template('admin/admin_requests.html',data=res,dataa= resa)









@app.route('/admin_admin_requests_post',methods=['post'])
def admin_admin_admin_requests_post():
    from_date=request.form['select']
    to=request.form['select2']
    # staffname=request.form['select3']
    c = Db()
    qry = "select staff.*,leave_req.* from leave_req,staff where leave_req.staff_id=staff.login_id and date between '"+from_date+"' and '"+to+"' "
    res = c.select(qry)
    q = "select * from staff"
    resa = c.select(qry)
    return render_template('admin/admin_requests.html', data=res, dataa=resa)


#
#
# @app.route('/admin_approve_requests_post/<id>/<sid>')
# def admin_admin_approve_requests_post(id,sid):
#     db=Db()
#
#     qry1="SELECT `leave_req`.`date` from leave_req WHERE `leave_request_id`='"+id+"'"
#     print(qry1)
#     res1=db.selectOne(qry1)
#     dat=res1["date"]
#     qry2="SELECT DATE_FORMAT('"+str(dat)+"','%W')"
#     dat2=db.selectOne(qry2)
#     print(dat2)
#     day=dat2["DATE_FORMAT('"+str(dat)+"','%W')"]
#     print(day)
#     day=str(day).lower()
#     counter=0
#     course_ids=[]
#     sems=[]
#     hrss=[]
#     qry3="SELECT * FROM `subject` INNER JOIN `subject_staff_allocation` ON `subject_staff_allocation`.`subject_id`=`subject`.`subject_id`INNER  JOIN `staff` ON `staff`.`login_id`=`subject_staff_allocation`.`staff_id` INNER JOIN `time_table` ON `time_table`.`subject`=`subject`.`subject_id` INNER JOIN course ON `course`.`course_id`=`subject`.`course_name` WHERE `subject_staff_allocation`.`staff_id`='"+sid+"' AND `time_table`.`day`='"+str(day)+"'   "
#     data3=db.select(qry3)
#     # print(qry3)
#     # print(data3)
#     for i in data3:
#         course_ids.append(str(i["course_id"]))
#         sems.append(str(i["semester"]))
#         hrss.append(str(i["hour"]))
#     print(hrss)
#     for i in range(len(sems)):
#         qry4="SELECT * FROM SUBJECT INNER JOIN `subject_staff_allocation` on `subject_staff_allocation`.`subject_id`=`subject`.`subject_id` WHERE `subject`.`course_name`='"+course_ids[i]+"' AND `subject`.`semester`='"+sems[i]+"' "
#         # print(qry4)
#         data5 =db.select(qry4)
#         for j in data5:
#             sub_id = str(j["subject_id"])
#             staff_id = str(j["staff_id"])
#             # print(data5)
#
#             qry7="SELECT COUNT(tid),`subject`.`subject_id` FROM `time_table` INNER JOIN `subject` ON `subject`.`subject_id`=`time_table`.`subject` INNER JOIN `subject_staff_allocation` ON `subject_staff_allocation`.`subject_id`=`subject`.`subject_id` WHERE `subject_staff_allocation`.`staff_id`='"+staff_id+"' and day='"+day+"'"
#             data6=db.selectOne(qry7)
#             # print(qry7)
#             # print(data6)
#             if data6 is not None:
#                 count=data6["COUNT(tid)"]
#
#                 print("aaaaaaaaa")
#                 print(count)
#                 if int(count)<4 and counter<len(sems):
#                     qry8="SELECT * FROM `timetable_change` WHERE `course_id`='"+course_ids[i]+"' AND `semester`='"+sems[i]+"' AND `date`='"+str(day)+"' AND HOUR='"+hrss[i]+"'"
#                     rr8=db.selectOne(qry8)
#                     print(rr8,"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa")
#                     print("bbb",counter,len(sems))
#                     if rr8 is None:
#                         qry6="INSERT INTO `timetable_change` (`course_id`,`date`,`semester`,`hour`,`subject_id`)VALUES('"+course_ids[i]+"','"+str(dat)+"','"+sems[i]+"','"+hrss[i]+"','"+sub_id+"') "
#                         db.insert(qry6)
#                         counter+=1
#
#                         qqr="SELECT * FROM `timetable_change` INNER JOIN `subject_staff_allocation` ON `subject_staff_allocation`.`subject_id`=`timetable_change`.`subject_id` INNER JOIN `staff` ON `staff`.`login_id`=`subject_staff_allocation`.`staff_id` where login_id='"+staff_id+"'"
#                         prog=db.selectOne(qqr)
#                         if prog is not None:
#                             mail_id=prog["mail_id"]
#                             msg = Message('Hello', sender='devagiricollege.leavemanagement@gmail.com', recipients=['nadhaashraf12@gmail.com'])
#                             msg.body = "Hello "+ prog["staff_name"] +", There is a change in "+ str(dat)+"'s Timetable. Please Check it out !!!"
#                             mail.send(msg)
#
#                         break
#
#                 # else:
#                 #     break
#             # else:
#             #     continue
#     qry="update leave_req set status='accepted' where leave_request_id='"+str(id)+"'"
#     res=db.update(qry)
#
#     return '''<script>alert('accepted'); window.location='/admin_admin_requests' </script>'''
#
#





@app.route('/admin_approve_requests_post/<id>/<sid>')
def admin_admin_approve_requests_post(id,sid):
    db=Db()
    qry = "update leave_req set status='accepted' where leave_request_id='" + str(id) + "'"
    res = db.update(qry)
    qry1="SELECT date from leave_sub WHERE `leave_id`='"+id+"'"
    print(qry1)
    res1=db.select(qry1)
    for my in res1:
        dat=my["date"]

        qry2="SELECT DATE_FORMAT('"+str(dat)+"','%W')"
        dat2=db.selectOne(qry2)
        print(dat2)
        day=dat2["DATE_FORMAT('"+str(dat)+"','%W')"]
        print(day)
        day=str(day).lower()
        counter=0
        course_ids=[]
        sems=[]
        hrss=[]
        qry3="SELECT * FROM `subject` INNER JOIN `subject_staff_allocation` ON `subject_staff_allocation`.`subject_id`=`subject`.`subject_id`INNER  JOIN `staff` ON `staff`.`login_id`=`subject_staff_allocation`.`staff_id` INNER JOIN `time_table` ON `time_table`.`subject`=`subject`.`subject_id` INNER JOIN course ON `course`.`course_id`=`subject`.`course_name` WHERE `subject_staff_allocation`.`staff_id`='"+sid+"' AND `time_table`.`day`='"+str(day)+"'   "
        data3=db.select(qry3)
        # print(qry3)
        # print(data3)
        for i in data3:
            course_ids.append(str(i["course_id"]))
            sems.append(str(i["semester"]))
            hrss.append(str(i["hour"]))
        print(hrss)
        for i in range(len(sems)):
            qry4="SELECT * FROM SUBJECT INNER JOIN `subject_staff_allocation` on `subject_staff_allocation`.`subject_id`=`subject`.`subject_id` WHERE `subject`.`course_name`='"+course_ids[i]+"' AND `subject`.`semester`='"+sems[i]+"' "
            # print(qry4)
            data5 =db.select(qry4)
            for j in data5:
                sub_id = str(j["subject_id"])
                staff_id = str(j["staff_id"])
                # print(data5)

                qry7="SELECT COUNT(tid),`subject`.`subject_id` FROM `time_table` INNER JOIN `subject` ON `subject`.`subject_id`=`time_table`.`subject` INNER JOIN `subject_staff_allocation` ON `subject_staff_allocation`.`subject_id`=`subject`.`subject_id` WHERE `subject_staff_allocation`.`staff_id`='"+staff_id+"' and day='"+day+"'"
                data6=db.selectOne(qry7)
                # print(qry7)
                # print(data6)
                if data6 is not None:
                    count=data6["COUNT(tid)"]

                    print("aaaaaaaaa")
                    print(count)
                    if int(count)<4 and counter<len(sems):
                        qry8="SELECT * FROM `timetable_change` WHERE `course_id`='"+course_ids[i]+"' AND `semester`='"+sems[i]+"' AND `date`='"+str(day)+"' AND HOUR='"+hrss[i]+"'"
                        rr8=db.selectOne(qry8)
                        print(rr8,"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa")
                        print("bbb",counter,len(sems))
                        if rr8 is None:
                            qry6="INSERT INTO `timetable_change` (`course_id`,`date`,`semester`,`hour`,`subject_id`)VALUES('"+course_ids[i]+"','"+str(dat)+"','"+sems[i]+"','"+hrss[i]+"','"+sub_id+"') "
                            db.insert(qry6)
                            counter+=1

                            qqr="SELECT * FROM `timetable_change` INNER JOIN `subject_staff_allocation` ON `subject_staff_allocation`.`subject_id`=`timetable_change`.`subject_id` INNER JOIN `staff` ON `staff`.`login_id`=`subject_staff_allocation`.`staff_id` where login_id='"+staff_id+"'"
                            prog=db.selectOne(qqr)
                            if prog is not None:
                                mail_id=prog["mail_id"]
                                msg = Message('Hello', sender='devagiricollege.leavemanagement@gmail.com', recipients=['nadhaashraf12@gmail.com'])
                                msg.body = "Hello "+ prog["staff_name"] +", There is a change in "+ str(dat)+"'s Timetable. Please Check it out !!!"
                                mail.send(msg)

                            break

                    # else:
                    #     break
                # else:
                #     continue


    return '''<script>alert('accepted'); window.location='/admin_admin_requests' </script>'''


@app.route('/admin_reject_requests_post/<id>')
def admin_admin_reject_requests_post(id):
    db=Db()

    return render_template("admin/Message.html",id=id)



@app.route('/admin_reject_requests_post_post',methods=['POST'])
def admin_reject_requests_post_post():
    db=Db()
    message=request.form["textfield"]
    id=request.form["ii"]
    qry="update leave_req set status='rejected',message='"+message+"' where leave_request_id='"+str(id)+"'"
    res=db.update(qry)
    return '''<script>alert('rejected'); window.location='/admin_admin_requests' </script>'''


@app.route('/admin_ADMIN_VIEW_ALLOCATE')
def admin_admin_view_allocate():
    db=Db()
    qry="select * from course"
    res=db.select(qry)

    qry1="SELECT * FROM `staff` INNER JOIN `subject_staff_allocation` ON `subject_staff_allocation`.`staff_id`=`staff`.`login_id` INNER JOIN `subject` ON `subject`.`subject_id`=`subject_staff_allocation`.`subject_id` INNER JOIN `course` ON `course`.`course_id`=`subject`.`course_name`"
    res1=db.select(qry1)
    return render_template('admin/ADMIN_VIEW_ALLOCATE.html',data=res,data1=res1)

@app.route('/admin_ADMIN_VIEW_ALLOCATE_post',methods=['post'])
def admin_admin_view_allocate_post():
    course=request.form['select']
    sem=request.form['select2']
    db = Db()
    qry = "select * from course"
    res = db.select(qry)

    qry1 = "SELECT * FROM `staff` INNER JOIN `subject_staff_allocation` ON `subject_staff_allocation`.`staff_id`=`staff`.`login_id` INNER JOIN `subject` ON `subject`.`subject_id`=`subject_staff_allocation`.`subject_id` INNER JOIN `course` ON `course`.`course_id`=`subject`.`course_name` where course_id='"+course+"' and semester='"+sem+"'"
    res1 = db.select(qry1)
    return render_template('admin/ADMIN_VIEW_ALLOCATE.html', data=res, data1=res1)



@app.route("/admin_ADMIN_delete_ALLOCATE/<id>")
def aa(id):
    db = Db()
    qry = "delete from subject_staff_allocation where satff_subject_id='"+id+"'"
    res = db.delete(qry)
    return admin_admin_view_allocate()



@app.route('/admin_admin_view_sub')
def admin_admin_view_sub():
    c = Db()
    qry = "select subject.*,subject.semester as sem,course.* from subject,course where course.course_id=subject.course_name"
    res2 = c.select(qry)
    qry = "select * from course"
    res = c.select(qry)
    return render_template('admin/Admin_view_sub.html', data=res2, data1=res)





@app.route('/admin_admin_view_sub_post',methods=['post'] )
def admin_admin_view_sub_post():
    course = request.form['select']
    sem = request.form['select2']
    c = Db()
    qry = "select subject.*,subject.semester as sem,course.* from subject inner join course on course.course_id=subject.course_name where subject.course_name='"+str(course)+"' and subject.semester='"+str(sem)+"'"
    res2 = c.select(qry)
    qry = "select * from course"
    res = c.select(qry)
    return render_template('admin/Admin_view_sub.html', data=res2, data1=res)



@app.route('/admin_admin_view_sub_del/<v>')
def admin_admin_view_sub_del(v):
    c = Db()
    qry = "delete from subject where subject_id='"+v+"'"
    res2 = c.delete(qry)
    return admin_admin_view_sub()

@app.route('/admin_admin_view_sub_edit/<v>')
def admin_admin_view_sub_edit(v):
    c = Db()
    qry="select * from subject where subject_id='"+v+"'"
    res=c.selectOne(qry)
    qry2="select course.* from course,subject where subject.course_name=course.course_id and subject.subject_id='"+v+"'"
    res2=c.selectOne(qry2)
    qry3="select * from course"
    res3=c.select(qry3)
    return render_template("admin/admin_edit_sub.html",data=res,data2=res2,data3=res3)




@app.route('/admin_editsub_post',methods=['post'])
def admin_editsub_post():
    coursename= request.form['select']
    subname=request.form['textfield2']
    subcode=request.form['textfield']
    semester=request.form['select2']
    subid=request.form['subid']
    db = Db()
    print(coursename,subname,subcode,semester)
    qry = "update subject set course_name='"+coursename+"',subject_name='"+subname+"',subcode='"+subcode+"',semester='"+semester+"' where subject_id='"+subid+"'"
    res = db.update(qry)
    return admin_admin_view_sub()




@app.route('/admin_ALLOCATE')
def admin_Allocate():
    db=Db()
    qry="select * from course"
    res=db.select(qry)
    qry = "select * from staff"
    res1 = db.select(qry)
    return render_template('admin/ALLOCATE.html',data=res,dd=res1)

@app.route('/admin_ALLOCATE_post',methods=['post'])
def admin_Allocate_post():

    subject=request.form['select3']
    staff=request.form['select4']
    bb="SELECT * FROM `subject_staff_allocation` WHERE subject_id='"+subject+"'"
    db=Db()
    res=db.selectOne(bb)
    if res is not None:
        satff_subject_id=str(res['satff_subject_id'])
        up="UPDATE `subject_staff_allocation` SET `staff_id`='"+staff+"' WHERE `satff_subject_id`='"+satff_subject_id+"'"
        db.update(up)
    else:
        qry="INSERT INTO `subject_staff_allocation` (`subject_id`,`staff_id`)VALUES('"+subject+"','"+staff+"') "
        db.insert(qry)
    return admin_Allocate()

@app.route('/adminviewcomplaint')
def adminviewcomplaint():
    db=Db()
    qry="select complaint.*,staff.* from staff inner join complaint on staff.staff_id=complaint.staff_id"
    res = db.select(qry)
    print(res)
    return render_template('admin/adminveiwcomplaint.html',data=res)

@app.route('/admin_Reply_complain/<id>')
def admin_Reply_complaint(id):
    db = Db()
    qry = "select complaint.*,staff.* from staff inner join complaint on staff.staff_id=complaint.staff_id Where complaint.complaint_id='"+id+"'"
    res = db.selectOne(qry)
    return render_template('admin/Reply complaint.html', rep=res)

@app.route('/admin_Reply_complain_post',methods=['post'])
def admin_Reply_complaint_post():
    cid = request.form['c_id']
    reply=request.form['textarea']
    db = Db()
    qry = "update complaint set reply='"+reply+"', status='replied' where complaint_id='"+cid+"'"
    res = db.update(qry)
    return '''<script>alert('Send');window.location='/adminviewcomplaint'</script>'''
@app.route('/admin_timetable')
def admin_timetable():
    c=Db()
    qry="select * from course"
    res=c.select(qry)

    qry2 = "select * from subject"
    res2 = c.select(qry2)
    print(res2)
    return render_template('admin/timetable.html',data=res,data2=res2)

@app.route('/admin_timetable',methods=['post'])
def admin_timetable_post():
    course=request.form['select']
    semester=request.form['select2']
    subject=request.form['select3']
    day=request.form['select4']
    hour=request.form['select5']

    db = Db()
    qry ="insert into time_table(day,hour,course,semester,subject)VALUES ('"+day+"','"+hour+"','"+course+"','"+semester+"','"+subject+"')"
    print(qry)
    res = db.insert(qry)
    return admin_timetable()





#________________________________________________________________________________________________










@app.route('/teacher_change_password')
def teacher_change_password():
    return render_template('teacher/Teacher change password.html')

@app.route('/teacher_change_password_post',methods=['post'])
def teacher_change_password_post():
    newpassword=request.form['textfield']
    password2=request.form['textfield2']
    password1=request.form['textfield3']
    db=Db()
    qry="select * from login where password='"+password1+"' and login_ID='"+str(session['l_id'])+"' "
    res=db.selectOne(qry)
    if res!=None:
        qry1="update login set password='"+password2+"' where login_ID='"+str(session['l_id'])+"' "
        res1=db.update(qry1)
    return render_template('teacher/Teacher change password.html')

@app.route('/Teacher_request_leave')
def teacher_request_leave():
    return render_template('teacher/TEACHER REQUEST LEAVE.HTML')

@app.route('/Teacher_request_leave_post',methods=['post'])
def teacher_request_leave_post():


    date_to=request.form['select2']
    ff1=request.form["select25"]
    reason=request.form['textarea']
    db = Db()
    qry = "insert into leave_req(date,reason,status,staff_id,date_to)values('"+date_to+"','"+reason+"','pending','"+str(session["l_id"])+"','"+ff1+"')"
    res = db.insert(qry)
    qqrr="SELECT DATEDIFF(date_to,date) as d FROM `leave_req` WHERE `leave_request_id`='"+str(res)+"'"
    print(qqrr)
    ff=db.selectOne(qqrr)
    count=int(ff["d"])

    for i in range(count+1):
        if i == 0:
            rdate=date_to
            qrt="INSERT INTO `leave_sub`(`date`,`leave_id`) VALUES('"+rdate+"','"+str(res)+"')"
            db.insert(qrt)
        else:
            q1 = "SELECT DATE_ADD('" +rdate+"', INTERVAL 1 DAY) as a;  "
            rr=db.selectOne(q1)
            rdate=rr['a']
            qrt = "INSERT INTO `leave_sub`(`date`,`leave_id`) VALUES('" + rdate + "','" + str(res) + "')"
            db.insert(qrt)
    return '''<script>alert('Success');window.location='/Teacher_request_leave'</script>'''

@app.route('/teacher_send_complaint')
def teacher_send_complaint():
    return render_template('teacher/Teacher send complaint.html')

@app.route('/teacher_send_complaint_post',methods=['post'])
def teacher_send_complaint_post():
    write_complaint=request.form['textarea']
    qry="INSERT INTO `complaint`(`staff_id`,`date`,`complaint`,`reply`,`status`)VALUES('"+str(session["l_id"])+"',CURDATE(),'"+write_complaint+"','pending','pending')"
    db=Db()
    db.insert(qry)
    return '''<script>alert('Success');window.location='/teacher_send_complaint'</script>'''

@app.route('/teacher_view_timetable')
def teacher_view_timetable():
    c = Db()
    qry = "select * from course"
    res = c.select(qry)

    qrr="SELECT * FROM `subject` INNER JOIN `subject_staff_allocation` ON `subject_staff_allocation`.`subject_id`=`subject`.`subject_id`INNER JOIN `timetable_change` ON `timetable_change`.`subject_id`=`subject`.`subject_id` INNER JOIN `course` ON `course`.`course_id`=`subject`.`course_name`WHERE `timetable_change`.date>CURDATE() AND `subject_staff_allocation`.`staff_id`='"+str(session["l_id"])+"'"
    db=Db()
    re=db.select(qrr)
    print(re)
    return render_template('teacher/Teacher veiw Timeable.html',data=res,status="null",ll=len(re),re=re)

@app.route('/teacher_view_timetable_post',methods=['post'])
def teacher_view_timetable_post():
    coursename=request.form['select']
    semester=request.form['select2']
    c = Db()
    qry = "select * from course"
    res = c.select(qry)
    qry1="select subject.subject_id,subject.subject_name,time_table.tid from subject inner join time_table on time_table.subject=subject.subject_id where day='monday' and time_table.course='"+coursename+"' and time_table.semester='"+semester+"'"
    d1=c.select(qry1)
    qry2 = "select subject.subject_id,subject.subject_name,time_table.tid from subject inner join time_table on time_table.subject=subject.subject_id where day='tuesday' and time_table.course='" + coursename + "' and time_table.semester='" + semester + "'"
    d2 = c.select(qry2)
    qry3 = "select subject.subject_id,subject.subject_name,time_table.tid from subject inner join time_table on time_table.subject=subject.subject_id where day='wednesday' and time_table.course='" + coursename + "' and time_table.semester='" + semester + "'"
    d3 = c.select(qry3)
    print(d3)
    qry4 = "select subject.subject_id,subject.subject_name,time_table.tid from subject inner join time_table on time_table.subject=subject.subject_id where day='thursday' and time_table.course='" + coursename + "' and time_table.semester='" + semester + "'"
    d4 = c.select(qry4)
    qry5 = "select subject.subject_id,subject.subject_name,time_table.tid from subject inner join time_table on time_table.subject=subject.subject_id where day='friday' and time_table.course='" + coursename + "' and time_table.semester='" + semester + "'"
    d5 = c.select(qry5)

    qrr = "SELECT * FROM `subject` INNER JOIN `subject_staff_allocation` ON `subject_staff_allocation`.`subject_id`=`subject`.`subject_id`INNER JOIN `timetable_change` ON `timetable_change`.`subject_id`=`subject`.`subject_id` INNER JOIN `course` ON `course`.`course_id`=`subject`.`course_name`WHERE `timetable_change`.date>CURDATE() AND `subject_staff_allocation`.`staff_id`='" + str(
        session["l_id"]) + "'"
    db = Db()
    re = db.select(qrr)
    return render_template('teacher/Teacher veiw Timeable.html',data=res,d1=d1,d2=d2,d3=d3,d4=d4,d5=d5,status="full",ll=len(re),re=re)





@app.route('/teacher_view_allocate_timetable')
def teacher_view_allocate_timetable():
    c = Db()
    qry = "select * from course"
    res = c.select(qry)
    qq="SELECT * FROM `course` INNER JOIN `subject` ON `subject`.`course_name`=`course`.`course_id` INNER JOIN `subject_staff_allocation` ON `subject_staff_allocation`.`subject_id`=`subject`.`subject_id` WHERE `subject_staff_allocation`.`staff_id`='"+str(session["l_id"])+"'"
    rr=c.select(qq)
    return render_template('teacher/Teacher view allocated subject.html',data=res,data2=rr)

@app.route('/teacher_view_allocate_timetable_post',methods=['post'])
def teacher_view_allocate_timetable_post():
    course = request.form['select']
    sem = request.form['select2']
    c = Db()
    qry = "select * from course"
    res = c.select(qry)
    qq = "SELECT * FROM `course` INNER JOIN `subject` ON `subject`.`course_name`=`course`.`course_id` INNER JOIN `subject_staff_allocation` ON `subject_staff_allocation`.`subject_id`=`subject`.`subject_id` WHERE `subject_staff_allocation`.`staff_id`='" + str(session["l_id"]) + "' and course_id='"+course+"' and semester='"+sem+"'"
    rr = c.select(qq)
    return render_template('teacher/Teacher view allocated subject.html',data=res,data2=rr)

@app.route('/teacher_view_complaint')
def teacher_view_complaint():
    qry="select * from `complaint` WHERE `staff_id`='"+str(session["l_id"])+"'"
    db=Db()
    res=db.select(qry)
    return render_template('teacher/Teacher view complaint.html',data=res)


@app.route('/teacher_view_profile')
def teacher_view_profile():
    qry="SELECT * FROM `staff` WHERE `login_id`='"+str(session["l_id"])+"'"
    db=Db()
    res=db.selectOne(qry)
    return render_template('teacher/Teacher view profile.html',d=res)

@app.route('/teacher_view_status')
def teacher_VIEW_STATUS():
    qry="SELECT * FROM `leave_req` WHERE `staff_id`='"+str(session["l_id"])+"'"
    db=Db()
    res=db.select(qry)

    qq="SELECT COUNT(*) FROM `leave_req` WHERE `staff_id`='"+str(session["l_id"])+"' AND `status`='rejected'"
    ff=db.selectOne(qq)
    print(ff)
    qq1 = "SELECT COUNT(*) FROM `leave_req` WHERE `staff_id`='" + str(session["l_id"]) + "' AND `status`='pending'"
    ff1 = db.selectOne(qq1)

    qq11 = "SELECT COUNT(*) FROM `leave_req` WHERE `staff_id`='" + str(session["l_id"]) + "' "
    ff11 = db.selectOne(qq11)

    qq11 = "SELECT COUNT(*) FROM `leave_req` WHERE `staff_id`='" + str(session["l_id"]) + "'and status='accepted' and date<=curdate() "
    ff2 = db.selectOne(qq11)
    return render_template('teacher/TEACHER VIEW STATUS.html',data=res,rr=ff["COUNT(*)"],pr=ff1["COUNT(*)"],tr=ff11["COUNT(*)"],tlt=ff2["COUNT(*)"])

@app.route('/admin_home')
def admin_home():
    return render_template('admin/admin_home.html')

@app.route('/t_home')
def t_home():
    return render_template('teacher/home.html')
@app.route('/index_page')
def index_page():
    return render_template('index.html')


@app.route("/teacher_view_class_timetable")
def teacher_view_class_timetable():
    db=Db()
    monday=[]
    tuesday=[]
    wednesday=[]
    thursday=[]
    friday=[]
    for i in range(1,6):
        qry="SELECT * FROM `subject` INNER JOIN `subject_staff_allocation` ON `subject_staff_allocation`.`subject_id`=`subject`.`subject_id`INNER JOIN `time_table` ON `time_table`.`subject`=`subject`.`subject_id` WHERE `subject_staff_allocation`.`staff_id`='"+str(session["l_id"])+"' AND `time_table`.`day`='monday'AND `time_table`.`hour`='"+str(i)+"'"
        res=db.selectOne(qry)
        if res is not None:
            monday.append(res["subject_name"])
        else:
            monday.append("Free")
    for i in range(1,6):
        qry="SELECT * FROM `subject` INNER JOIN `subject_staff_allocation` ON `subject_staff_allocation`.`subject_id`=`subject`.`subject_id`INNER JOIN `time_table` ON `time_table`.`subject`=`subject`.`subject_id` WHERE `subject_staff_allocation`.`staff_id`='"+str(session["l_id"])+"' AND `time_table`.`day`='tuesday'AND `time_table`.`hour`='"+str(i)+"'"
        res=db.selectOne(qry)
        if res is not None:
            tuesday.append(res["subject_name"])
        else:
            tuesday.append("Free")
    for i in range(1,6):
        qry="SELECT * FROM `subject` INNER JOIN `subject_staff_allocation` ON `subject_staff_allocation`.`subject_id`=`subject`.`subject_id`INNER JOIN `time_table` ON `time_table`.`subject`=`subject`.`subject_id` WHERE `subject_staff_allocation`.`staff_id`='"+str(session["l_id"])+"' AND `time_table`.`day`='wednesday'AND `time_table`.`hour`='"+str(i)+"'"
        res=db.selectOne(qry)
        if res is not None:
            wednesday.append(res["subject_name"])
        else:
            wednesday.append("Free")
    for i in range(1,6):
        qry="SELECT * FROM `subject` INNER JOIN `subject_staff_allocation` ON `subject_staff_allocation`.`subject_id`=`subject`.`subject_id`INNER JOIN `time_table` ON `time_table`.`subject`=`subject`.`subject_id` WHERE `subject_staff_allocation`.`staff_id`='"+str(session["l_id"])+"' AND `time_table`.`day`='thursday'AND `time_table`.`hour`='"+str(i)+"'"
        res=db.selectOne(qry)
        if res is not None:
            thursday.append(res["subject_name"])
        else:
            thursday.append("Free")
    for i in range(1,6):
        qry="SELECT * FROM `subject` INNER JOIN `subject_staff_allocation` ON `subject_staff_allocation`.`subject_id`=`subject`.`subject_id`INNER JOIN `time_table` ON `time_table`.`subject`=`subject`.`subject_id` WHERE `subject_staff_allocation`.`staff_id`='"+str(session["l_id"])+"' AND `time_table`.`day`='friday'AND `time_table`.`hour`='"+str(i)+"'"
        res=db.selectOne(qry)
        if res is not None:
            friday.append(res["subject_name"])
        else:
            friday.append("Free")
    qq = "SELECT * FROM `course` INNER JOIN `subject` ON `subject`.`course_name`=`course`.`course_id` INNER JOIN `subject_staff_allocation` ON `subject_staff_allocation`.`subject_id`=`subject`.`subject_id` WHERE `subject_staff_allocation`.`staff_id`='" + str(
        session["l_id"]) + "' "
    rr = db.select(qq)
    return render_template("teacher/Teacher_view_college_timetable.html",monday=monday,thursday=thursday,tuesday=tuesday,wednesday=wednesday,friday=friday,data=rr)







if __name__ == '__main__':
    app.run(debug=True)


